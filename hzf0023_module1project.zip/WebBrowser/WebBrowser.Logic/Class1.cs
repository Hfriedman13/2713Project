﻿using System;

namespace WebBrowser.Logic
{
    public class Class1
    {
    }
}
